package net.mcreator.infinitytrain.procedure;

import net.minecraft.world.World;
import net.minecraft.entity.Entity;

import net.mcreator.infinitytrain.ElementsInfinityTrain;

@ElementsInfinityTrain.ModElement.Tag
public class ProcedureGhomThisEntityKillsAnotherOne extends ElementsInfinityTrain.ModElement {
	public ProcedureGhomThisEntityKillsAnotherOne(ElementsInfinityTrain instance) {
		super(instance, 12);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure GhomThisEntityKillsAnotherOne!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure GhomThisEntityKillsAnotherOne!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		World world = (World) dependencies.get("world");
		if (!world.isRemote) {
			world.createExplosion(null, (int) (entity.posX), (int) (entity.posY), (int) (entity.posZ), (float) 5, true);
		}
	}
}
